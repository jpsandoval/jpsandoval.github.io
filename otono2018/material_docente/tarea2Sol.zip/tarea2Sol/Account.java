abstract class Account{
    protected double balance;
    protected int transactions;
    public Account(double b){
        balance=b;
        transactions=0;
    }
    public void withdraw(double amt){
        balance=balance-amt;
        transactions++;
    }
    public void deposit(double amt){
        balance=balance+amt;
        transactions++;
    }
    public void endMonth(){
        endMonthCharge();
        transactions=0;
    }
    public abstract void endMonthCharge();
}