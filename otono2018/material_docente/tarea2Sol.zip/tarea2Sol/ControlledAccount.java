public class ControlledAccount extends Account{
    
    public ControlledAccount(double d){
        super(d);
    }
    
    public void endMonthCharge(){
        if(transactions>=30){
            balance= balance-10;
        }
    }
}