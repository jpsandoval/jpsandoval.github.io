public abstract class Figure{
    abstract double area();
    abstract double perimeter();
    @Override
    public String toString(){
        return "Figure: ";
    }
}