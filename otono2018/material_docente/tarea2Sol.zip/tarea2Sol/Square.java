public class Square extends Figure{
    private int side;
    Square(int s){
        side=s;
    }
    public double area(){
        return side*side;
    }
    public double perimeter(){
        return side*4;
    }
    public String toString(){
        return super.toString()+": Cuadrado -"+side;
    }
}