public class NickleNDimeAccount extends Account{
    private int withdraws;
    public NickleNDimeAccount(double b){
        super(b);
        withdraws=0;
    }
    public void withdraw(double amt){
        super.withdraw(amt);
        withdraws++;
    }
    public void endMonthCharge(){
        balance=balance - withdraws*0.5;
    }
}