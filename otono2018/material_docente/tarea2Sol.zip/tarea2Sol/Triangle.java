public class Triangle extends Figure{
    private int height;
    private int base;
    Triangle(int h,int b){
        height=h;
        base=b;
    }
    public double area(){
        return base*height/2;
    }
    public double perimeter(){
        double x=Math.sqrt(height*height)+ (base/2)*(base/2);
        return 2*x+base;
    }
    public String toString(){
        return super.toString()+": Triangulo -"+base+"-"+height;
    }
}