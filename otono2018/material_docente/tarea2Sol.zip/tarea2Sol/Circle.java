public class Circle extends Figure{
    private int ratio;
    
    public Circle(int r){
        ratio=r;
    }
    
    public double perimeter(){
        return 2*Math.PI*ratio;
    }
    public double area(){
        return Math.PI*ratio*ratio;    
    }
    public String toString(){
        return super.toString()+": Circulo-"+ratio;
    }
}