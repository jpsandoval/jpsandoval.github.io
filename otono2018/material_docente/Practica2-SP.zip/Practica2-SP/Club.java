
public class Club {
	private MemberShip[] members;
	private int size;
	private int capacity;
	 Club(){
		capacity=100;
		size=0;
		members=new MemberShip[capacity];
	}
	public void add(MemberShip m){
		if(size<capacity){
			members[size]=m;
			size++;
		}
	}
	/**
	 * 5. contar cuantos miembros ingresaron al club en el mes
	 * pasado como argumento
	 */
	public int numberOfMembers(int m){
		return 0;
	}
	
	/**
	 * 6. verifica si existe un miembro con el nombre pasado 
	 * como parametro
	 */
	public int verify(String name){
		return 0;
	}
}
