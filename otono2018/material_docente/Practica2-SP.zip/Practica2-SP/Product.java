
public class Product {
	private String name;
	private double price;
	private int amount;//cantidad
	public Product(String name, double price, int amount) {
		super();
		this.name = name;
		this.price = price;
		this.amount = amount;
	}
	
}
