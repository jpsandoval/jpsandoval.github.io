
public class MemberShip {
	private String fullName;
	private int registrationMonth;
	private int registrationYear;
	private int age;
	public MemberShip(String fullName, int registrationMonth, int registrationYear) {
		super();
		this.fullName = fullName;
		this.registrationMonth = registrationMonth;
		this.registrationYear = registrationYear;
	}
	
	
}
