
public class MainClass {
	public static void main(String[] args) {
		Stock stock=new Stock();
		stock.add(new Product("pan",0.5,100));
		stock.add(new Product("leche",4.5,20));
		stock.add(new Product("galleta",7.5,75));
		System.out.println(stock.stockValue());
		//...
		Club club=new Club();
		club.add(new MemberShip("juampi", 7, 2012));
		club.add(new MemberShip("jose", 8, 2013));
		System.out.println(club.numberOfMembers(7));
		
		
	}
}
