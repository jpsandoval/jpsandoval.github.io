
public class Stock {
	private Product[] products;
	private int size; 
	private int capacity;
	Stock(){
		size=0;
		capacity=100;
		products=new Product[capacity];
	}
	public void add(Product p){
		if(size<capacity){// si hay espacio
			products[size]=p;
			size++;
		}
	}
	public int size(){
		return size;
	}
	/**
	 * 1. Escriba un metodo que devuelva el producto mas caro
	 * @return
	 */
	public Product mostExpensiveProduct(){
		return null;
	}
	/**
	 * 2. Escriba un metodo que devuelva el producto que tenga 
	 * el mismo nombre que la cadena pasada como parametro
	 * 
	 * @param name
	 * @return
	 */
	public Product productNamed(String name){
		return null;
	}
	/**
	 * 3. Escriba un método que devuelva el valor total del stock
	 * el total es la suma del precio de todos los productos, 
	 * multiplicado por su cantidad
	 */
	public double stockValue(){
		return 0;
	}
	/**
	 * 4. Escriba un método que devuelva el numero de productos
	 * con cantidad=0;
	 */
	public int outStockProducts(){
		return 0;
	}
	
}
