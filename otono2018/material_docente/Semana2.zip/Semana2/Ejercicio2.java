import java.util.*;
public class Ejercicio2{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int hours=in.nextInt();
        int days= hours/24;
        int remainingHours= days%24;
        System.out.println(days);
        System.out.println(remainingHours);
    }
}
