import java.util.*;
public class Ejercicio1{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int celsius = in.nextInt();
        double fahrenheit = 9.0/5.0*celsius+32;
        System.out.println(fahrenheit);
    }
}
