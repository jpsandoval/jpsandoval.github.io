
public class MainClass {
	public static void main(String[] args) {
		Stock stock=new Stock();
		stock.add(new Product("pan",0.5,100));
		stock.add(new Product("leche",4.5,50));
		stock.add(new Product("galleta",7.5,75));
		stock.add(new OfferProduct("chocolike",1.0,20,2.0));
		stock.printAsList();
		
		
	}
}
