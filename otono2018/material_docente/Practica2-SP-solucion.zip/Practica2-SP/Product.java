
public class Product {
    private String name;
    private double price;
    private int amount;//cantidad
    public Product(String name, double price, int amount) {
        super();
        this.name = name;
        this.price = price;
        this.amount = amount;
    }
    public void sell(int c){
        amount = amount - c;
    }
    public boolean outStock(){
        return amount==0;
    }
    public double totalValue(){
        return price*amount;
    }
    public double getPrice(){
        return price;
       }
    public String toString(){
        return name+"="+ price+" * "+ amount;
    }
    public String getName(){
        return name;
    }
}
