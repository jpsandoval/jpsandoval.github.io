
public class Stock {
    private Product[] products;
    private int size; 
    private int capacity;
    Stock(){
        size=0;
        capacity=100;
        products=new Product[capacity];
    }
    public void add(Product p){
        if(size<capacity){// si hay espacio
            products[size]=p;
            size++;
        }
    }
    public int size(){
        return size;
    }
    /**
     * 1. Escriba un metodo que devuelva el producto mas caro
     * @return
     */
    public Product mostExpensiveProduct(){
        Product masCaro=products[0];
        for(int i=1;i<size;i++){
            if(products[i].getPrice() > masCaro.getPrice()){
            masCaro=products[i];
           }
        }
        return masCaro;
    }
    /**
     * 2. Escriba un metodo que devuelva el producto que tenga 
     * el mismo nombre que la cadena pasada como parametro
     * 
     * @param name
     * @return
     */
    public Product productNamed(String name){
        Product result=null;
        for(int i=0;i<size;i++){
            if(products[i].getName().equals(name)){
                result=products[i];
            }
        }
        return result;
    }
    /**
     * 3. Escriba un método que devuelva el valor total del stock
     * el total es la suma del precio de todos los productos, 
     * multiplicado por su cantidad
     */
    public double stockValue(){
        double acum=0;
        for(int i=0;i<size;i++){
            acum=acum+ products[i].totalValue();
        }
        return acum;
    }
    /**
     * 4. Escriba un método que devuelva el numero de productos
     * con cantidad=0;
     */
    public int outStockProducts(){
        int count=0;
        for(int i=0;i<size;i++){
            if(products[i].outStock()){
                count++;
            }
        }
        return count;
    }
    public void sell(String name,int c){
        Product p=this.productNamed(name);
        p.sell(c);
    }
    
    public void printAsList(){
        for(int i=0;i<size;i++){
            System.out.println(products[i].getName());
        }
    }
}
