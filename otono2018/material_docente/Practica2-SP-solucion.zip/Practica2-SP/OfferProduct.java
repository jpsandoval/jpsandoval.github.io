public class OfferProduct extends Product{
    private double discount;
    public OfferProduct(String name, double price, int amount, double d){
        super(name,price,amount);
        discount=d;
    }
    public String getName(){
        return "*"+super.getName();
    }
}
