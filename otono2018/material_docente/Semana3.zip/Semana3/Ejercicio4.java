import java.util.*;
/**
 * Dados 3 nuemros enteros, si fueron ingresados en ordern
 * imprimir "en orden", sino, imprimir "no esta en orden"
 */
public class Ejercicio4{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int a = in.nextInt();
        int b = in.nextInt();
        int c = in.nextInt();
        if(a<b && b<c){
            System.out.println("en orden");
        }else{
            System.out.println("no esta en orden");
        }
    }
}






