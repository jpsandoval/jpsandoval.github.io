import java.util.*;
public class Ejercicio1{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
        double hipo = Math.sqrt(a*a+b*b);
        
        System.out.println(hipo);
        
    }
}
