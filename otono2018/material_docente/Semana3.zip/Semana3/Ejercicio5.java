import java.util.*;
class Ejercicio5{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int num=in.nextInt();
        if(num<0){
            num = num * -1;
        }
        System.out.println(num);
    }
}