import java.util.*;
/**
 * Ejercicio 2: dado un numero entero leido de 
 * consola, imprimir si es par o impar
 */
public class Ejercicio2{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int x = in.nextInt();
        if(x%2==0){
            System.out.println("par");
        }else{
            System.out.println("impar");
        }
    }
}


