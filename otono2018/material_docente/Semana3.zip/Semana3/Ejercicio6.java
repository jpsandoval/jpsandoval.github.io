import java.util.*;

public class Ejercicio6{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int nota=in.nextInt();
        if(nota>=90){
            System.out.println("A");
        }else{
            if(nota>=80){
                System.out.println("B");
            }else{
                if(nota>=70){
                    System.out.println("C");
                }else{
                    if(nota>=65){
                        System.out.println("D");
                    }else{
                        System.out.println("F");
                    }
                }
            }
        }
    }
}
