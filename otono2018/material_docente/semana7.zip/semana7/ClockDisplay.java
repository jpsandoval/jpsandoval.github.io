class ClockDisplay{
    private ClockNumber hour;
    private ClockNumber minute;
    ClockDisplay(int h,int m){
        hour=new ClockNumber(h,24);
        minute=new ClockNumber(m,60);
    }
    void increment(){
        if(minute.increment()){
            hour.increment();
        }
        
    }
    String asString(){
        return hour.asString()+":"+minute.asString();
    }
}



