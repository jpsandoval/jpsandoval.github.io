class BankAccount{
    private int accountNumber;
    private String onwerName;
    private int balance;
    BankAccount(int an,String on){
        accountNumber=an;
        onwerName=on;
        balance=0;
    }
    String balanceDetails(){
        return accountNumber+" saldo: "+ balance;
    }
    void deposit(int amount){
        balance = balance + amount;
    }
    int withdraw(int amount){
        balance = balance - amount;
        return amount;
    }

}