class Punto{
    // datos
    private int x;
    private int y;
    // constructor
    Punto(int value){
        x=value;
        y=value;
    }
    // operaciones asociadas a los datos
    /**
     * @param dx distancia a moverse
     */ 
    void moveHorizontal(int dx){
        x = x + dx;
    }
    /**
     * convierte los datos del objeto
     * a string.
     */
    String asString(){
        return x+" , "+y;
    }
    
}