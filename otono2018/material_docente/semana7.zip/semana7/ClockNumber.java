class ClockNumber{
        private int value;
        private int limit;
        ClockNumber(int v,int l){
            value=v;
            limit=l;
        }
        boolean increment(){
            value = (value +1)%limit;
            return value==0;
        }
        String asString(){
            if(value<10)return "0"+ value;
            else return ""+value;
        }
        
}