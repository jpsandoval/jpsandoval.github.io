public class Mate{
    
    double abs(double value){
        return value<0?value*-1:value;
    }
    int abs(int value){
        return value<0?value*-1:value;
    }
}
