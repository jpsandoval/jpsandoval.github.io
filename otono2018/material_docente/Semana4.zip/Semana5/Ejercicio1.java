import java.util.*;
/**
 * dado un numero determinar si es primo o no
 */
public class Ejercicio1{
    public static void main(String args[]){
        Scanner in=new Scanner(System.in);
        int num= in.nextInt();
        int counter=0;
        for(int i=1;i<num;i++){   
            if(num%i==0){
                counter++;
            }
        }
        if(counter==2){
            System.out.println("es primo");
        }else{
            System.out.println("no es primo");
        }
    }
}
