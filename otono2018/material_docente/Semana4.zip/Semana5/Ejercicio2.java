import java.util.*;
/**
 * dado un numero imprimir la tabla de multiplicar de ese numero
 */
public class Ejercicio2{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int num=in.nextInt();
        for(int i=1;i<=10;i++){
            System.out.println(i+"x"+num+" = "+ (i*num));
        }
    }

}