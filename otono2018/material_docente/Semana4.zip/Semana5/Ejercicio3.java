import java.util.*;
/**
 * hallar el mayor de 100 numeros leidos desde teclado
 */
public class Ejercicio3{
    public static void main(String[] args){
        Scanner in=new Scanner(System.in);
        int num=in.nextInt();
        int max=num;
        for(int i=1;i<100;i++){
            num=in.nextInt();
            if(num>max){
                max=num;
            }
        }
        System.out.println(max);
    }
}